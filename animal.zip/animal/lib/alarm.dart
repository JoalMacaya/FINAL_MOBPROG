// alarm.dart
class Alarm {
  int id;
  String title;
  DateTime time;

  Alarm({required this.id, required this.title, required this.time});
}
