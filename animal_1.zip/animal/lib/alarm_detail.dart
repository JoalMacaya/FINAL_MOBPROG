// alarm_detail.dart
import 'package:flutter/material.dart';
import 'alarm.dart';

class AlarmDetail extends StatefulWidget {
  final Alarm? alarm;

  const AlarmDetail({Key? key, this.alarm}) : super(key: key);

  @override
  _AlarmDetailState createState() => _AlarmDetailState();
}

class _AlarmDetailState extends State<AlarmDetail> {
  late TextEditingController _titleController;
  late TimeOfDay _selectedTime;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.alarm?.title ?? '');
    _selectedTime = TimeOfDay.fromDateTime(widget.alarm?.time ?? DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        brightness: Brightness.dark, // Set background to black
        primaryColor: Colors.blue, // Customize your primary color
        hintColor: Colors.blueAccent, // Customize your accent color
        scaffoldBackgroundColor: Colors.black, // Set scaffold background color to black
        // Add more theme configurations as needed
      ),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Alarm Detail'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(
                controller: _titleController,
                style: const TextStyle(color: Colors.blueAccent), // Set text color to light blue
                decoration: const InputDecoration(
                  labelText: 'Title',
                  labelStyle: TextStyle(color: Colors.blueAccent), // Set label color to light blue
                ),
              ),
              const SizedBox(height: 16.0),
              Row(
                children: <Widget>[
                  const Text(
                    'Select Time:',
                    style: TextStyle(color: Colors.blueAccent), // Set text color to light blue
                  ),
                  const SizedBox(width: 16.0),
                  TextButton(
                    onPressed: () async {
                      TimeOfDay? pickedTime = await showTimePicker(
                        context: context,
                        initialTime: _selectedTime,
                        builder: (BuildContext context, Widget? child) {
                          return Theme(
                            data: ThemeData.dark().copyWith(
                              primaryColor: Colors.blueAccent, // Set the primary color for the dark theme
                              hintColor: Colors.blueAccent, // Set the accent color for the dark theme
                              buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
                              // Add more theme configurations as needed
                            ),
                            child: child!,
                          );
                        },
                      );
                      if (pickedTime != null) {
                        setState(() {
                          _selectedTime = pickedTime;
                        });
                      }
                    },
                    child: Text(
                      '${_selectedTime.hour}:${_selectedTime.minute}',
                      style: const TextStyle(color: Colors.blueAccent), // Set text color to light blue
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  Alarm newAlarm = Alarm(
                    id: widget.alarm?.id ?? DateTime.now().millisecondsSinceEpoch,
                    title: _titleController.text,
                    time: DateTime(
                      DateTime.now().year,
                      DateTime.now().month,
                      DateTime.now().day,
                      _selectedTime.hour,
                      _selectedTime.minute,
                    ),
                  );
                  Navigator.pop(context, newAlarm);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent, // Set button background color to transparent
                  side: const BorderSide(color: Colors.blueAccent), // Set button outline color to light blue
                ),
                child: const Text(
                  'Save',
                  style: TextStyle(color: Colors.blueAccent), // Set button text color to light blue
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
