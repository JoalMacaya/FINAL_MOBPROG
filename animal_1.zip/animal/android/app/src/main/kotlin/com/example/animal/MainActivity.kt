package com.example.animal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
