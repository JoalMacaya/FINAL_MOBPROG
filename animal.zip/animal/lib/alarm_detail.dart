// alarm_detail.dart
import 'package:flutter/material.dart';
import 'alarm.dart';

class AlarmDetail extends StatefulWidget {
  final Alarm? alarm;

  const AlarmDetail({Key? key, this.alarm}) : super(key: key);

  @override
  _AlarmDetailState createState() => _AlarmDetailState();
}

class _AlarmDetailState extends State<AlarmDetail> {
  late TextEditingController _titleController;
  late TimeOfDay _selectedTime;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.alarm?.title ?? '');
    _selectedTime = TimeOfDay.fromDateTime(widget.alarm?.time ?? DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alarm Detail'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            SizedBox(height: 16.0),
            Row(
              children: [
                Text('Select Time:'),
                SizedBox(width: 16.0),
                TextButton(
                  onPressed: () async {
                    TimeOfDay? pickedTime = await showTimePicker(
                      context: context,
                      initialTime: _selectedTime,
                    );
                    if (pickedTime != null) {
                      setState(() {
                        _selectedTime = pickedTime;
                      });
                    }
                  },
                  child: Text('${_selectedTime.hour}:${_selectedTime.minute}'),
                ),
              ],
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Alarm newAlarm = Alarm(
                  id: widget.alarm?.id ?? DateTime.now().millisecondsSinceEpoch,
                  title: _titleController.text,
                  time: DateTime(
                    DateTime.now().year,
                    DateTime.now().month,
                    DateTime.now().day,
                    _selectedTime.hour,
                    _selectedTime.minute,
                  ),
                );
                Navigator.pop(context, newAlarm);
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
