// main.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:timezone/timezone.dart' as tz;
import 'alarm_helper.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alarm App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AlarmScreen(),
    );
  }
}

class AlarmScreen extends StatefulWidget {
  @override
  _AlarmScreenState createState() => _AlarmScreenState();
}

class _AlarmScreenState extends State<AlarmScreen> {
  @override
  void initState() {
    super.initState();
    AlarmHelper.initialize();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alarm Screen'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            _scheduleAlarm();
          },
          child: Text('Set Alarm'),
        ),
      ),
    );
  }

  void _scheduleAlarm() {
    DateTime now = DateTime.now();
    DateTime scheduledTime = now.add(Duration(seconds: 10)); // Set your desired time here
    String title = 'Alarm Title';
    String body = 'Wake up!';

    AlarmHelper.scheduleNotification(title, body, scheduledTime);

    // Optional: You can use this callback to handle the alarm when it triggers.
    // For example, navigate to a screen or perform a specific action.
    // You can also schedule recurring alarms using a periodic callback.
    Timer(scheduledTime.difference(now), () {
      // This code will run when the alarm triggers
      print('Alarm Triggered!');
    });
  }
}
