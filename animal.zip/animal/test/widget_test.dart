import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() {
  runApp(MyApp());
}

class Alarm {
  int id;
  TimeOfDay time;
  String label;
  bool isEnabled;

  Alarm({required this.id, required this.time, required this.label, required this.isEnabled});
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Alarm App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AlarmListScreen(),
    );
  }
}

class AlarmListScreen extends StatefulWidget {
  @override
  _AlarmListScreenState createState() => _AlarmListScreenState();
}

class _AlarmListScreenState extends State<AlarmListScreen> {
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  List<Alarm> alarms = [];

  @override
  void initState() {
    super.initState();
    initializeNotifications();
    loadAlarms();
  }

  void initializeNotifications() async {
    final settingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    final settingsIOS = IOSInitializationSettings();
    final settings = InitializationSettings(android: settingsAndroid, iOS: settingsIOS);

    await flutterLocalNotificationsPlugin.initialize(settings, onSelectNotification: (payload) async {
      // Handle when the user taps on a notification (e.g., navigate to the alarm details screen).
    });
  }

  void loadAlarms() {
    // Load alarms from storage (for demonstration, you can use a database or local storage).
    // This is a simplified example, so we'll use dummy data.
    setState(() {
      alarms = [
        Alarm(id: 1, time: TimeOfDay(hour: 8, minute: 0), label: 'Wake up', isEnabled: true),
        Alarm(id: 2, time: TimeOfDay(hour: 12, minute: 0), label: 'Lunch time', isEnabled: true),
        Alarm(id: 3, time: TimeOfDay(hour: 18, minute: 0), label: 'Dinner time', isEnabled: true),
      ];
    });
  }

  void addOrUpdateAlarm(Alarm alarm) {
    // Add or update the alarm in the list (for demonstration, you can use a database or local storage).
    setState(() {
      if (alarms.any((a) => a.id == alarm.id)) {
        // Update existing alarm
        alarms[alarms.indexWhere((a) => a.id == alarm.id)] = alarm;
      } else {
        // Add new alarm
        alarms.add(alarm);
      }
    });

    // Schedule or cancel the local notification based on the isEnabled flag.
    if (alarm.isEnabled) {
      scheduleNotification(alarm);
    } else {
      cancelNotification(alarm.id);
    }
  }

  void deleteAlarm(int id) {
    // Delete the alarm from the list (for demonstration, you can use a database or local storage).
    setState(() {
      alarms.removeWhere((alarm) => alarm.id == id);
    });

    // Cancel the local notification for the deleted alarm.
    cancelNotification(id);
  }

  void scheduleNotification(Alarm alarm) async {
    await flutterLocalNotificationsPlugin.zonedSchedule(
      alarm.id,
      'Alarm: ${alarm.label}',
      'It\'s time!',
      _nextInstanceOfAlarm(alarm),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'your channel id',
          'your channel name',
          'your channel description',
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  TZDateTime _nextInstanceOfAlarm(Alarm alarm) {
    final now = TZDateTime.now(tz.local);
    final nextAlarmTime = TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      alarm.time.hour,
      alarm.time.minute,
    );

    return nextAlarmTime.isBefore(now) ? nextAlarmTime.add(Duration(days: 1)) : nextAlarmTime;
  }

  void cancelNotification(int id) async {
    await flutterLocalNotificationsPlugin.cancel(id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alarm App'),
      ),
      body: ListView.builder(
        itemCount: alarms.length,
        itemBuilder: (context, index) {
          final alarm = alarms[index];
          return ListTile(
            title: Text('${alarm.time.format(context)} - ${alarm.label}'),
            subtitle: Text(alarm.isEnabled ? 'Enabled' : 'Disabled'),
            trailing: IconButton(
              icon: Icon(Icons.edit),
              onPressed: () {
                // Navigate to the Add/Edit Alarm screen when the edit button is pressed.
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddEditAlarmScreen(
                      initialAlarm: alarm,
                      onAlarmChanged: addOrUpdateAlarm,
                    ),
                  ),
                );
              },
            ),
            onLongPress: () {
              // Delete the alarm when it is long-pressed.
              deleteAlarm(alarm.id);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to the Add/Edit Alarm screen when the FloatingActionButton is pressed.
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddEditAlarmScreen(
                onAlarmChanged: addOrUpdateAlarm,
              ),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class AddEditAlarmScreen extends StatefulWidget {
  final Alarm? initialAlarm;
  final Function(Alarm) onAlarmChanged;

  AddEditAlarmScreen({Key? key, this.initialAlarm, required this.onAlarmChanged}) : super(key: key);

  @override
  _AddEditAlarmScreenState createState() => _AddEditAlarmScreenState();
}

class _AddEditAlarmScreenState extends State<AddEditAlarmScreen> {
  late TimeOfDay selectedTime;
  late String label;
  late bool isEnabled;

  @override
  void initState() {
    super.initState();

    if (widget.initialAlarm != null) {
      selectedTime = widget.initialAlarm!.time;
      label = widget.initialAlarm!.label;
      isEnabled = widget.initialAlarm!.isEnabled;
    } else {
      selectedTime = TimeOfDay.now();
      label = '';
      isEnabled = true;
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );

    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add/Edit Alarm'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ListTile(
              title: Text('Time'),
              subtitle: Text(selectedTime.format(context)),
              onTap: () => _selectTime(context),
            ),
            ListTile(
              title: Text('Label'),
              subtitle: TextField(
                onChanged: (value) => label = value,
                controller: TextEditingController(text: label),
              ),
            ),
            SwitchListTile(
              title: Text('Enabled'),
              value: isEnabled,
              onChanged: (value) {
                setState(() {
                  isEnabled = value;
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final newAlarm = Alarm(
                  id: widget.initialAlarm?.id ?? DateTime.now().millisecondsSinceEpoch,
                  time: selectedTime,
                  label: label,
                  isEnabled: isEnabled,
                );

                // Call the callback function to add or update the alarm in the list.
                widget.onAlarmChanged(newAlarm);

                // Pop the screen to go back to the Alarm List screen.
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
