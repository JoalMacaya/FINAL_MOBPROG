// alarm_list.dart
import 'package:flutter/material.dart';
import 'alarm.dart';
import 'alarm_detail.dart';

class AlarmList extends StatefulWidget {
  @override
  _AlarmListState createState() => _AlarmListState();
}

class _AlarmListState extends State<AlarmList> {
  List<Alarm> alarms = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alarm List'),
      ),
      body: ListView.builder(
        itemCount: alarms.length,
        itemBuilder: (context, index) {
          return Dismissible(
            key: Key(alarms[index].id.toString()),
            onDismissed: (direction) {
              setState(() {
                alarms.removeAt(index);
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Alarm deleted'),
                ),
              );
            },
            background: Container(
              color: Colors.red,
              child: Icon(Icons.delete, color: Colors.white),
            ),
            child: ListTile(
              title: Text(alarms[index].title),
              subtitle: Text('${alarms[index].time.hour}:${alarms[index].time.minute}'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AlarmDetail(alarm: alarms[index]),
                  ),
                ).then((newAlarm) {
                  if (newAlarm != null) {
                    setState(() {
                      alarms[index] = newAlarm;
                    });
                  }
                });
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AlarmDetail(),
            ),
          ).then((newAlarm) {
            if (newAlarm != null) {
              setState(() {
                alarms.add(newAlarm);
              });
            }
          });
        },
        tooltip: 'Add Alarm',
        child: Icon(Icons.add),
      ),
    );
  }
}
